java -jar sum-exec.jar

