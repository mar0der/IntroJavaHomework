#bin/sh
java -jar DeckOfCards.jar
